# readthrough

## The objective

**An HTML page that tells you what is in a recording and what is worth cutting
out of it.** One file, opens by double-clicking, no server.

Everything before that page is working material. `moments.json` is not the
deliverable. `turn-stills.json` is not the deliverable. A run that writes JSON
and stops has produced nothing anybody asked for, and `run.py` exits non-zero
when that happens, because it happened on 2026-09-07: the pass was run on an
episode, the JSON was written, no page was built, and the run was reported as
finished.

## The flow

```bash
python scripts/run.py --captions CAPTIONS.vtt --video IN.mp4 --out-dir inbox/x --title "..."
```

Four steps, each writing a file the next one reads. Three are scripts. One is
the AI running the workflow, and no script can take it.

| Step | In | Out |
|---|---|---|
| `find_moments.py` | captions | `moments.json` |
| **the read** | the whole transcript, read by the AI against the checklist in `SKILL.md` | `segments.json` |
| `pick_turn_stills.py` | video plus either JSON | `turn-stills.json`, `segment-stills.json` |
| `build_readthrough.mjs` | everything above | **`walkthrough.html`** |

`--video` is optional and the page is built without pictures when it is absent.
When `segments.json` is missing, `run.py` prints the prompt for the read, builds
the page from the mechanical pass, and the page says at the top that the
recording has not been read, with the same prompt and a copy button.

The last thing `run.py` does is open the page it built and check it has a
title, stat cards, the filters, the timeline and at least one ranked card.
Missing any of those is a failure, not a warning.

## Why the read is a step

`find_moments.py` matches phrases. On Founder's Couch Episode One the host said
"Today, our guest speaker is Joe" and "this gentleman over here Gavin is going
to talk about Purely", neither was on the list, and the page went out with the
first 79 minutes as one card and nobody in it named. Megan: "It was poorly done.
You didn't get the featured founders."

The phrases are on the list now, and a fixture cut from those captions keeps
them there. That fixes Episode One. The next host will say it another way, so
the page is not built on the list alone: the AI reads the transcript end to end
and writes down who was up, when, what they said, where the demo was, who the
sponsor was, every name in the round, the questions and the close. That file is
`segments.json` and the timeline is drawn from it.

## The page is the cut-proposals page

Megan, 2026-09-07: "There's one in my downloads folder that I liked a lot. It
had the actual show timeline with sections cut out showing where the features
actually lived." That page is `20260828_founders-couch-ep02_cut-proposals-1.html`,
"What is in Episode Two", and a copy sits beside the Episode Two run as
`_reference-cut-proposals-20260828.html`.

So the walkthrough is, in order: a stamp saying when it was read, stat cards,
the filters, the show timeline with one proportional block per segment and a
tick per moment, the segment list with a duration and a line each, the guest
and the featured founders as their own section with a frame, in and out, a
lede, their words as quote cards and the reader's marks, every moment in
order, then every segment as a ranked card with the lines that passed the test
and a Copy button holding a prompt that cuts from it, and one dark final call.

The timeline and founder rules are vendored as `cut-proposals.template.css`,
with that page's token names aliased onto the First Look sheet. The hero, the
stat cards, the ranked cards and the final call are `first-look.template.css`.
Nothing is authored. `first-look.template.js` is deprecated: this page has no
modal, and its final button showed a toast about a Reel lens.

**The filters.** Every kind looked for sits at the top with its count, zeros
included, plus what the read adds (guest, featured founder, demo, the reader's
marks) and what the picture adds (slides on screen, screen share). Click one
and the timeline ticks and the moment list show only that kind. A zero on the
page is a miss somebody can see; a zero in a JSON is not.

## A demo comes from the picture, not the captions

Every kind in `moment_kinds.py` is read from captions. A demo is not in the
captions: `video-tools/CHANGELOG.md` defines a demo stretch by the picture, a
full-screen screen share, no couch, no inset. The stills pass writes four
numbers for every sampled frame, and the page reads two things off them:

- **Slides on screen.** Frames the stills test flagged as graphics, crisp and
  still, in runs of four samples or more, joined into blocks when the room cuts
  back in between. Named in and out on the card.
- **Screen only.** Frames with nobody in shot that the graphics test did not
  take, because they move. `subject_frac` is the share of the frame in a
  skin-tone range; camera frames read 0.42 on Episode One and 0.09 to 0.16 in
  the Prickly Pear room, and slides and the demo read 0.006 to 0.034. The floor
  is 0.05. Three samples or more, named in and out. On Episode One every one
  of those was a screen capture. On the Gardens talk they were the room camera
  zoomed onto the TV, 21 times, which reads the same and is not a share. The
  page says what was measured, the screen and nothing else, and a person says
  which.

A run without stills says so instead of guessing, and a manifest from before
the numbers were written says that too.

It was a ratio first: a stretch was a demo when more than half its samples were
graphics. Then the first recording with a known demo went through. Episode One
has 48 seconds of live demo at 26:51, and the ratio saw nothing: 157 graphic
samples in 786 on a 79 minute stretch. The times showed 13 runs, a slide
section from 20:56 to 37:14, and the demo in none of them, because its frames
move and the graphics test reads still. The numbers per frame are what found
it.

## What a moment is

A point in the recording where something known happens. The kinds are rows in
`scripts/moment_kinds.py`, and adding a kind is adding a row.

| Kind | What it marks |
|---|---|
| `handoff` | The host hands over and says who is next. |
| `self-intro` | Somebody says their own name: "my name is", or "I'm" followed by a word that could be a name. A name is read from "my name is", or from two capitalised words after "I'm". |
| `invite-intro` | The host opens the floor for people to introduce themselves. |
| `to-room` | A question aimed at everybody rather than one person. |
| `sponsor` | Who paid for the room, said out loud. |
| `what-this-is` | The recording describing itself. |
| `closing` | The end, said out loud. |

A kind marked `bounds` can open a stretch of the recording, and the stretches
partition it. A recording with no bounding moment gets one stretch, the whole
thing, and its moments still land inside it.

**A zero is an answer.** The page and the JSON both say which kinds were looked
for and not found. Read on three recordings on 2026-09-07, none lights up every
kind:

| | Prickly Pear, 2:56 | Founder's Couch E2, 1:12 | Founder's Couch E1, 1:37 |
|---|---|---|---|
| handoff | 6 | 0 | 0 |
| self-intro | 3 | 7 | 4 |
| invite-intro | 0 | 2 | 1 |
| to-room | 9 | 1 | 0 |
| sponsor | 0 | 1 | 1 |
| what-this-is | 0 | 1 | 1 |
| closing | 4 | 2 | 0 |

The first two columns moved when Episode One went through. Prickly Pear lost
four self-introductions that were places ("this is Tempe school district") and
Episode Two gained two that were people ("I'm Deji", "I'm Ryan Racy"). The
pages built for those two recordings earlier that day carry the older read.

**The opening is a stretch.** Everything before the first bounding moment used
to belong to no stretch, and the page dropped it without saying so. On Episode
One the first boundary is at 1:19:25, so the talk, the sponsor and the demo all
sat in the 79 minutes that were not on the page. The opening stretch has no
`opened_by`, and the page calls it the whole recording up to the first boundary.

## It leverages the other tools and edits none of them

`pick_turn_stills.py` hands work to `../stills/scripts/pick_stills.py` by
subprocess. The stills tool is not imported, not patched and not configured from
here. It goes on working exactly the same run on its own, and so does every other
tool in this folder. Nothing in this workflow reaches into `shorts/`, `tighten/`
or `loudness/`.

The one thing borrowed rather than called is the candidate test, which is the
mechanical half of `../shorts/references/selection.md`, restated in
`find_moments.py` rather than imported, so `shorts` has no dependency pointing
back at this.

## Checking a change

```bash
python tests/run_tests.py
```

Four fixtures, three formats, under two seconds. `founders-couch-e1.vtt` carries
the guest speaker and both featured founders as the answer key. Each is a verbatim slice of a real
recording, so a pattern that passes here works on tape rather than on something
written to make it pass.

Checking a pattern change used to mean re-processing a 2h56m video and a 1h12m
one, twenty minutes of stills included, and overwriting both recordings' outputs.

`--accept` rewrites the expectations. Read the diff first: it records whatever
runs now, correct or not.

The fixtures do not ship. They are transcript excerpts of named people speaking
at real events, so `.packageignore` keeps `tests/` out of the zip.

## What it does not do

- **It does not say who is speaking.** A name is read out of the sentence beside
  it and travels with that sentence so the two can be checked against each other.
  Both recordings carry a wrong name in the transcript itself: "Megan Dakota" for
  Megan Ducote, and "Joseph Van Coley" for Joseph Bankole.
- **It cannot place a cut.** Every time is a caption timing, wrong by tens of
  milliseconds. Cut points come from `../shorts/scripts/find_edges.py`, off the
  waveform at 20ms.
- **It proposes and never chooses.** Four of the five parts of the selection test
  are judgment and a person applies them.
- **It reads captions, not audio.** A recording with no transcript needs one
  first, and `../CLAUDE.md` rule 4 has the trap: faster-whisper returns nothing
  at source level around -34 dBFS.

## Deprecated

`_deprecated/` holds `find_speakers.py`, which read only the handoff kind and
reported an entire conversation-format recording as empty.
