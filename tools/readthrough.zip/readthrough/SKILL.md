---
name: readthrough
description: Read a whole recording and produce one HTML page saying what is in it, who was up and when, where the demo and the sponsor were, and what is worth cutting. Use when somebody hands over a long video and wants to know what is in it without watching it, or before choosing clips from footage nobody has read yet. It proposes and never chooses.
---

# Readthrough

Captions in, one page out: `walkthrough.html`. The show as a timeline, every
segment with who and what, the guest and the featured founders with a frame
and their words, every moment found with a filter per kind, and a cut prompt
for each part.

Needs Python and Node. ffmpeg if you want frames.

## The one thing to know

**Two reads make the page, and you are the second one.** The scripts match
phrases in the captions and are the same every time. You read the whole
transcript against the checklist below and write `segments.json`. The page is
built from both. Without yours it still builds, and it says at the top that the
recording has not been read.

This is a rule because of Founder's Couch Episode One, 2026-09-07. The host
said "Today, our guest speaker is Joe" and "this gentleman over here Gavin is
going to talk about Purely". Neither phrase was on the list. The scripts ran,
the agent reported their counts, and the page went out with the guest and both
featured founders missing. Megan: "You didn't get the featured founders."
Nothing prevented the read. The workflow had no step that required it.

## Running it

```bash
python scripts/run.py --captions C.vtt --video IN.mp4 --out-dir inbox/my-recording --title "..."
```

It starts from a file you were given. There is no fetch-from-a-link step:
downloading from YouTube by script is against YouTube's terms, and the one
that did it is deprecated. The channel owner downloads from YouTube Studio, or
shares the master; Creatopia keeps the Founder's Couch masters on Drive.

`run.py` does four things. Three are scripts; one is you.

| Step | In | Out |
|---|---|---|
| `find_moments.py` | captions | `moments.json` |
| **the read** | the whole transcript, and you | `segments.json` |
| `pick_turn_stills.py` | video plus either JSON | `turn-stills.json`, `segment-stills.json` |
| `build_readthrough.mjs` | everything above | **`walkthrough.html`** |

When `segments.json` is missing, `run.py` prints the prompt for the read,
builds the page anyway, and the page carries the same prompt with a copy
button. Do the read, then rebuild:

```bash
node scripts/build_readthrough.mjs inbox/my-recording
```

## The read, and the checklist

Read every caption line from the first to the last. Not the moments file, not
a search: the transcript, end to end. Then write `segments.json` beside it.

Look for every one of these, and when you find none, say so in the file:

- **The opening**, and who is introduced in it.
- **A guest speaker**: who, their company, what they talked about.
- **Each featured founder**: who, their company, in and out, what they said,
  and the lines worth quoting with their times.
- **A demo**: who, in, out, what was on the screen. The page checks it against
  the picture and says whether a full-screen share was seen there.
- **The sponsor**: who, and the sentence that named them.
- **The round of introductions**: every name, in order, with the company the
  captions heard.
- **Questions from the room**: each one, in a line.
- **The closing**: who, and what they asked the room to do.

Names are as the captions heard them unless you know them, and you say which.
The captions wrote "Joelart" and "Jose Van" on Episode One for Joe and for
Joseph Bankole.

Every time is a caption timing. Find it in the caption file, do not estimate
it. A time locates a passage; a cut point comes off the waveform.

## The shape of segments.json

```json
{
  "schema": "readthrough-segments/v1",
  "title": "Founders Couch: E1",
  "runs_to_s": 5828,
  "read": {"by": "an agent, reading the captions end to end", "on": "2026-09-07", "captions": "affo21-2ndA.en-orig.vtt"},
  "segments": [
    {"id": "guest", "kind": "guest", "title": "Guest speaker", "who": "Joe Alapart", "who_known": false,
     "company": "Lion Guard", "in": 65, "out": 1136, "what": "one paragraph, what was said",
     "quotes": [{"at": 260, "text": "the line, verbatim"}],
     "marks": [{"at": 1084, "what": "something worth knowing is here"}]},
    {"id": "featured-1", "kind": "featured", "order": "first", "title": "Featured founder, first",
     "who": "Megan Ducote", "who_known": true, "company": "Houston Bloom", "in": 1154, "out": 3035, "what": "...", "quotes": [], "marks": []}
  ],
  "demos": [{"in": 1606, "out": 1659, "who": "Megan Ducote", "what": "what was on the screen"}],
  "sponsor": {"at": 1138, "who": "Paint the Town Red", "said": "the sentence"}
}
```

Segment `kind` is one of `opening`, `guest`, `featured`, `round`, `questions`,
`closing`, or anything else the recording needs. Segments do not overlap and
together they cover the recording. `guest` and `featured` get the person block
on the page, with a frame, the quotes as cards and the marks as a list.
Everything else gets a timeline block, a link and a ranked card.

## What the page shows

In order: the stamp saying when it was read, stat cards, the filters (every
kind looked for with its count, zeros included, click one to show only that
kind), the show timeline with one block per segment and a tick per moment, the
segment list, the people, every moment in order, then every segment as a ranked
card with the lines that passed the test and a Copy button holding a prompt
that cuts from it.

The shape is `20260828_founders-couch-ep02_cut-proposals-1.html`, the page Megan
kept. Its timeline and founder styles are vendored beside the builder as
`cut-proposals.template.css`; the hero, stat cards, ranked cards and final call
come from `first-look.template.css`. Nothing is authored.

## What comes from the picture

The stills pass writes four numbers per sampled frame. Slides on screen are
runs of crisp still frames; "screen only" is a run of frames with nobody in
shot that the slide test did not take: a capture, or the camera on the screen. Both are named in and out on the page,
and a manifest from before those numbers were written says so instead of
guessing. Measured 2026-09-07 on Episode One: the slide section 20:56 to 37:14
and the demo at 26:57 to 27:39, both found; the demo is not a slide, because it
moves.

## What a candidate line is

The mechanical half of the test in `../shorts/references/selection.md`: a
complete sentence at or above the word floor, not a greeting or a thank-you,
nothing reaching outside itself, not a question, at most one disfluency,
something asserted, at least 30 seconds past the boundary. Ranked, not
chronological.

**It proposes and never chooses.** The other four parts of the test are
judgment and a person applies them.

## What it does not do

- **It does not say who is speaking.** A `name_read` in `moments.json` is a
  reading of a sentence. A `who` in `segments.json` is your reading of the
  transcript, and you mark whether it is known.
- **It cannot place a cut.** Cut points are `../shorts/scripts/find_edges.py`.
- **The scripts do not read.** They match. The read is yours, every recording.

## Checking a change

```bash
python tests/run_tests.py
```

Four fixtures cut from real captions, Episode One among them, with the guest
speaker and both featured founders as the answer key. A pattern change that
loses one of them fails here in under two seconds. `--accept` rewrites the
expectations; read the diff first.
