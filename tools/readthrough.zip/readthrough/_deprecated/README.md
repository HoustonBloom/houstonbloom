# Deprecated

Nothing here is deleted. video-tools rule 7.

## `find_speakers.py (superseded 2026-09-07)`

Read one kind of moment, the host handing over to the next speaker, and returned
nothing at all when a recording had none. It found 6 turns on a 2h56m lineup and
0 on a 1h12m conversation, reporting the whole of the second recording as empty.

Superseded by `scripts/find_moments.py`, which reads every kind in
`scripts/moment_kinds.py` and reports which kinds it found none of. On the same
two recordings: 24 moments across 5 kinds, and 12 across 6.

Its output shape lives on: `pick_turn_stills.py` still reads a `turns_list` as
well as a `stretches`, so an old `speakers.json` on disk still renders.
