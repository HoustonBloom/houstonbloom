// moments.json -> the walkthrough page, in the shape of the First Look template.
//
//   node build_readthrough.mjs FOLDER [--out walkthrough.html]
//
// THE OBJECTIVE IS THIS FILE. Everything before it writes JSON so a person can
// check it. A run that produces moments.json and stops has not finished.
//
// THE SHAPE IS THE FIRST LOOK TEMPLATE. Megan, 2026-09-07: the walkthrough
// "should act like first looks for my cuts system". First Look is the Local
// Brain's onboarding template: a stamp and a one-line scan, stat cards for what
// was found, then ranked suggested-next cards, each with a preview on the left,
// what-it-is and why-use-it on the right, and a copy button, then one dark
// final call. "They don't want a wall of text. Stat cards, ranked publishing
// templates, copy buttons." That is the page now.
//
// THE TEMPLATE IS VENDORED, NOT WRITTEN. first-look.template.css and .js sit
// beside this file, lifted from the template's canonical example with their
// source named at the top. No CSS is authored here.
//
// WHAT WE LOOK FOR, AND THE ONE THAT COMES FROM THE PICTURE. Every kind in
// moment_kinds.py is read from captions: introductions, questions to the room,
// sponsors, the closing. A demo is not in the captions. video-tools/CHANGELOG
// defines a demo stretch by the picture: a full-screen screen share, no couch,
// no inset. The stills pass classifies every sampled frame as a graphic or not
// and, since 2026-09-07, writes where the graphic ones were. The page reads
// those times as blocks of slides on screen and names each block's in and out.
//
// It was a ratio first: a stretch was a demo when more than half its samples
// were graphics. Then the first recording with a known demo went through,
// Founders Couch Episode One, and the ratio saw nothing: 157 graphic samples
// in 786 on a 79 minute stretch. The times show 13 runs, a slide section from
// 20:56 to 37:14 with the room cut back in between, two more later. And the
// demo itself, 48 seconds at 26:51, is in none of them. See graphicBlocks.
//
// RANKING. The suggested cuts are the stretches, ranked by how many lines
// passed the candidate test. The top one gets the best-fit badge. Every card
// carries a prompt to paste that cuts from that stretch. It proposes; a person
// chooses.
//
// A FACE ON THIS PAGE IS FINE. This page is a private deliverable to the person
// who owns the recording, not a public site, so the preview on each card is the
// real frame the stills pass chose for that stretch.

import { readFileSync, writeFileSync, existsSync, statSync } from "node:fs";
import { resolve, dirname, join, basename } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const folder = args.find((a) => !a.startsWith("--"));
const flag = (n) => { const i = args.indexOf("--" + n); return i === -1 ? null : args[i + 1]; };
if (!folder) { console.error("Usage: node build_readthrough.mjs FOLDER [--out walkthrough.html]"); process.exit(1); }

const root = resolve(folder);
const momPath = join(root, "moments.json");
if (!existsSync(momPath)) {
  console.error("No moments.json in " + root + "\nRun this first:\n  python find_moments.py CAPTIONS.vtt --out moments.json");
  process.exit(1);
}
for (const f of ["first-look.template.css", "first-look.template.js"]) {
  if (!existsSync(join(HERE, f))) { console.error("Missing vendored template file beside this script: " + f); process.exit(1); }
}
const CSS = readFileSync(join(HERE, "first-look.template.css"), "utf8");
const JS = readFileSync(join(HERE, "first-look.template.js"), "utf8");
const DEFINED = new Set([...CSS.matchAll(/\.([a-zA-Z][\w-]*)/g)].map((m) => m[1]));

const mom = JSON.parse(readFileSync(momPath, "utf8"));
const segPath = join(root, "segments.json");
const seg = existsSync(segPath) ? JSON.parse(readFileSync(segPath, "utf8")) : null;
const srcPath = join(root, "source.json");
const src = existsSync(srcPath) ? JSON.parse(readFileSync(srcPath, "utf8")) : null;
const stillPath = join(root, "turn-stills.json");
const stills = existsSync(stillPath)
  ? new Map((JSON.parse(readFileSync(stillPath, "utf8")).turns ?? []).map((x) => [x.n, x]))
  : null;

const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const hms = (s) => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(x).padStart(2, "0")}` : `${m}:${String(x).padStart(2, "0")}`; };
const mins = (s) => `${Math.round(s / 60)} min`;
const embed = (f) => existsSync(f) ? "data:image/jpeg;base64," + readFileSync(f).toString("base64") : null;

const stretches = mom.stretches ?? [];
const moments = mom.moments ?? [];
const counts = mom.counts ?? {};
const total = mom.runs_to_s ?? (stretches.length ? stretches[stretches.length - 1].out : 0);
// A title comes from --title, then a segment index, then the source record, then
// the folder name made readable. "founders-couch-e2" is not a title.
const pretty = (s) => s.split(/[-_]+/).filter(Boolean).map((w) => /^e\d+$/i.test(w)
  ? "Episode " + w.slice(1) : w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
const title = flag("title") || seg?.title || src?.title || pretty(basename(root));
const linesTotal = stretches.reduce((n, s) => n + (s.candidates?.length ?? 0), 0);

// Graphics on screen in a stretch: runs of consecutive graphic samples, read
// from the stills manifest, never guessed. The stills test flags a frame that
// is crisp and still, which is a slide or a title card. A run shorter than
// MIN_RUN samples is a title card or a cutaway and is not reported; at the
// stills pass's 6 second sampling, four samples is 24 seconds. Runs closer
// together than BLOCK_GAP are one block, because a slide section is one thing
// to a reader even when the camera cuts back to the room between slides.
//
// The graphics test does not catch a moving screen share. Episode One's live
// demo at 26:51 sits in a 78 second gap between two slide runs: the frames
// are crisp, and they move, so the test keeps them as camera. What they have
// in common with the slides is that nobody is in them. The stills pass writes
// subject_frac for every sample, the share of the frame in a skin-tone range,
// and a full-screen share is a run of samples with nobody in shot that the
// graphics test did not take. Measured 2026-09-07: camera frames read 0.42 on
// Episode One and 0.09 to 0.16 in the Prickly Pear room; slides and the demo
// read 0.006 to 0.034. NOBODY sits between, with room on both sides.
const MIN_RUN = 4;
const BLOCK_GAP = 120;
const NOBODY = 0.05;
const SHARE_RUN = 3;
const graphicBlocks = (s) => {
  const t = stills?.get(s.n);
  if (!t || !Array.isArray(t.graphics_at_s)) return null;  // no manifest, or one from before the times were written
  const every = t.sampled_every_s || 6;
  const runs = [];
  let cur = null;
  for (const x of [...t.graphics_at_s].sort((a, b) => a - b)) {
    if (cur && x - cur.last <= every * 1.5) { cur.last = x; cur.n += 1; }
    else { if (cur) runs.push(cur); cur = { first: x, last: x, n: 1 }; }
  }
  if (cur) runs.push(cur);
  const blocks = [];
  for (const r of runs.filter((r) => r.n >= MIN_RUN)) {
    const b = blocks[blocks.length - 1];
    if (b && r.first - b.out <= BLOCK_GAP) { b.out = r.last + every; b.runs += 1; }
    else blocks.push({ in: r.first, out: r.last + every, runs: 1 });
  }
  return blocks;
};
const shareRuns = (s) => {
  const t = stills?.get(s.n);
  if (!t || !Array.isArray(t.samples)) return null;  // manifest from before the samples were written
  const f = t.samples_fields || ["t", "sharpness", "motion", "subject_frac"];
  const iT = f.indexOf("t"), iS = f.indexOf("subject_frac");
  const every = t.sampled_every_s || 6;
  const graphic = new Set((t.graphics_at_s || []).map((x) => Math.round(x)));
  const runs = [];
  let cur = null;
  for (const row of [...t.samples].sort((a, b) => a[iT] - b[iT])) {
    const x = row[iT];
    const nobody = row[iS] < NOBODY && !graphic.has(Math.round(x));
    if (nobody && cur && x - cur.last <= every * 1.5) { cur.last = x; cur.n += 1; }
    else if (nobody) { if (cur) runs.push(cur); cur = { first: x, last: x, n: 1 }; }
  }
  if (cur) runs.push(cur);
  return runs.filter((r) => r.n >= SHARE_RUN).map((r) => ({ in: r.first, out: r.last + every, n: r.n }));
};
const hasShare = (s) => (shareRuns(s) ?? []).length > 0;
const shareCount = stretches.reduce((n, s) => n + (shareRuns(s) ?? []).length, 0);
const sharesRead = stills !== null && stretches.some((s) => shareRuns(s) !== null);
const hasGraphics = (s) => (graphicBlocks(s) ?? []).length > 0;
const graphicStretches = stretches.filter(hasGraphics);
const blockCount = stretches.reduce((n, s) => n + (graphicBlocks(s) ?? []).length, 0);
const graphicsRead = stills !== null && stretches.some((s) => graphicBlocks(s) !== null);

const opener = (s) => s.opened_by ? (s.opened_by.name_read || s.opened_by.label) : (stretches.length > 1 ? "The opening" : "The whole recording");
const about = (s) => seg ? seg.segments.filter((p) => p.in < s.out && p.out > s.in).map((p) => p.title) : [];
const stillFor = (s) => { const t = stills?.get(s.n); return t?.still ? embed(join(root, t.still)) : null; };

// Ranked: most lines that passed the test first. Ties keep recording order.
const ranked = [...stretches].sort((a, b) => (b.candidates?.length ?? 0) - (a.candidates?.length ?? 0) || a.n - b.n);

const cutPrompt = (s) => {
  const top = (s.candidates ?? [])[0];
  return `Cut me a Short from the stretch that starts at ${s.at} (${opener(s)}). ` +
    (top ? `Open on the line at ${top.at}: "${top.text}". ` : "") +
    `Read video-tools/shorts/SKILL.md first, write the plan, show me the proof frame before rendering.`;
};

const kindLabel = { handoff: "Someone introduced", "self-intro": "Introduced themselves", "invite-intro": "Asked to introduce",
  "to-room": "Put to the room", sponsor: "Sponsor named", "what-this-is": "The recording describing itself", closing: "Closing" };

const stat = (n, label, tint) => `<div class="stat ${tint}"><div class="num">${esc(n)}</div><div class="label">${esc(label)}</div></div>`;

const card = (s, i) => {
  const top = i === 0;
  const pic = stillFor(s);
  const lines = s.candidates ?? [];
  const lead = lines[0];
  const kinds = (s.moments ?? []).map((m) => kindLabel[m.kind] || m.kind);
  const blocks = graphicBlocks(s);
  const shares = shareRuns(s);
  const shareNote = (blocks === null
    ? ""
    : blocks.length
      ? `; slides on screen ${blocks.map((b) => `${hms(b.in)} to ${hms(b.out)}`).join(", ")}`
      : "; no slides in the sampled frames")
    + (shares === null
      ? ""
      : shares.length
        ? `; screen share, moving and nobody in shot, ${shares.map((r) => `${hms(r.in)} to ${hms(r.out)}`).join(", ")}`
        : "");
  const preview = pic
    ? `<img src="${pic}" alt="A frame chosen from this stretch">`
    : `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid meet"><rect width="400" height="300" fill="#1f1d1a"/><text x="200" y="158" text-anchor="middle" font-family="JetBrains Mono, monospace" font-size="14" fill="#f5d88e">no frame picked</text></svg>`;
  return `<section class="lens${top ? " top-ranked" : ""}" id="s${s.n}">
  <div class="wrap">
    <div class="lens-grid">
      <div class="preview">${preview}</div>
      <div class="lens-body">
        <div class="lens-meta">
          <span class="badge ${top ? "best-fit" : "ready"}">${top ? "★ Best fit" : "Ready"}</span>
          <span>Stretch ${s.n} · ${esc(s.at)} · ${mins(s.dur_s)}</span>
          ${hasGraphics(s) ? `<span class="plan-flag">Slides on screen</span>` : ""}
          ${hasShare(s) ? `<span class="plan-flag">Screen share</span>` : ""}
        </div>
        <h2>${esc(opener(s))}</h2>
        <p class="tagline">${esc(about(s).join(". ") || (s.opened_by ? s.opened_by.said : ""))}</p>
        <div class="what"><div class="label">What is in it</div>
          <p>${lines.length} line${lines.length === 1 ? "" : "s"} passed the test${kinds.length ? "; " + esc(kinds.join(", ").toLowerCase()) : ""}${shareNote}.</p></div>
        ${lead ? `<div class="why"><div class="label">Open on this</div><p>&ldquo;${esc(lead.text)}&rdquo; <span class="dim">${esc(lead.at)}</span></p></div>` : ""}
        ${top ? `<div class="winner-note">★ Best fit : the stretch with the most lines that stand on their own.</div>` : ""}
        <button class="view-btn" type="button" data-prompt="${esc(cutPrompt(s))}">Copy the cut prompt <span class="arrow" aria-hidden="true">→</span></button>
      </div>
    </div>
  </div>
</section>`;
};

const kindsFound = Object.entries(counts).filter(([, v]) => v > 0);
const absent = (mom.kinds_absent ?? []).map((k) => kindLabel[k] || k);

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Walkthrough · ${esc(title)}</title>
<style>${CSS}</style>
</head>
<body>

<section class="hero">
  <div class="wrap">
    <span class="stamp">Walkthrough · First Look</span>
    <h1>${esc(title)}, <span class="ink-accent">read for you.</span></h1>
    <p class="sub">Who was up, when, what each stretch was about, and the lines worth cutting. Ranked below, with a prompt to paste for each.</p>
    <div class="meta">${esc(hms(total))} · ${stretches.length} stretches · ${moments.length} moments · ${linesTotal} lines proposed</div>
    <div class="stats">
      ${stat(stretches.length, "stretches", "sage")}
      ${stat(moments.length, "moments found", "butter")}
      ${stat(linesTotal, "lines worth cutting", "sky")}
      ${stat(sharesRead ? shareCount : graphicsRead ? blockCount : "n/a", sharesRead ? "screen shares seen" : "slide blocks seen", "")}
    </div>
  </div>
</section>

<section class="suggested-intro">
  <div class="wrap">
    <div class="kicker">What we look for</div>
    <h2>${kindsFound.length} kinds of moment found${absent.length ? ", " + absent.length + " looked for and absent" : ""}.</h2>
    <p>${kindsFound.map(([k, v]) => `<strong>${esc(kindLabel[k] || k)}</strong> ${v}`).join(" · ")}${graphicsRead ? ` · <strong>Slides on screen</strong> ${blockCount}` : ""}${sharesRead ? ` · <strong>Screen share</strong> ${shareCount}` : ""}${graphicsRead ? `, from the picture` : ""}.
    ${absent.length ? `Looked for and not found: ${esc(absent.join(", ").toLowerCase())}.` : ""}
    A name here is read from the sentence beside it, never a fact about who is speaking. Times locate a passage; a cut point still comes off the waveform.</p>
  </div>
</section>

${ranked.map(card).join("\n")}

<section class="final">
  <div class="wrap">
    <div class="kicker">Ready when you are</div>
    <h2>Want the best-fit cut made right now?</h2>
    <p>Paste the top card's prompt into your AI in the video-tools folder. You get a plan to approve, a proof frame to look at, and then the render.</p>
    <a href="#" class="big-btn" id="produce-btn" data-prompt="${esc(ranked.length ? cutPrompt(ranked[0]) : "")}">Copy the best-fit prompt <span aria-hidden="true">→</span></a>
    <div class="or-note">or copy any card above</div>
  </div>
</section>

<div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>
${JS}
</script>
<script>
(function(){
  var toast = document.getElementById('toast');
  function say(m){ if(!toast) return; toast.textContent = m; toast.classList.add('show'); setTimeout(function(){ toast.classList.remove('show'); }, 2200); }
  function copy(t){ if(navigator.clipboard && navigator.clipboard.writeText){ return navigator.clipboard.writeText(t); }
    var a=document.createElement('textarea'); a.value=t; a.style.position='fixed'; a.style.left='-9999px'; document.body.appendChild(a); a.select(); document.execCommand('copy'); document.body.removeChild(a); return Promise.resolve(); }
  document.addEventListener('click', function(e){
    var b = e.target.closest('[data-prompt]'); if(!b) return; e.preventDefault();
    copy(b.getAttribute('data-prompt')).then(function(){ say('Copied. Paste it into your AI.'); }, function(){ say('Copy failed. Select the text instead.'); });
  });
})();
</script>
</body>
</html>
`;

const used = new Set([...html.replace(/<script[\s\S]*?<\/script>/g, "").matchAll(/class="([^"]+)"/g)].flatMap((m) => m[1].split(/\s+/)).filter(Boolean));
const bad = [...used].filter((c) => !DEFINED.has(c)).sort();
if (bad.length) { console.error("Classes the template does not define:\n  " + bad.join(", ")); process.exit(1); }

const outPath = resolve(root, flag("out") || "walkthrough.html");
writeFileSync(outPath, html, "utf8");
console.log("wrote  " + outPath + "  " + statSync(outPath).size.toLocaleString() + " bytes");
console.log("shape  First Look: " + stretches.length + " ranked cards, " + moments.length + " moments, " + linesTotal + " lines, "
  + (graphicsRead ? blockCount + " slide blocks and " + (sharesRead ? shareCount : "no read of") + " screen shares from the picture"
      : stills ? "stills manifest predates the per-frame read, so no slide read" : "no stills manifest, so no slide read"));
