/* vendored with first-look.template.css, same source and date; the toast and copy handlers */

(function() {
  const toast = document.getElementById('toast');
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1800);
  }

  // Copy-to-clipboard for inline snippet buttons (YAML snippets in the growth guide)
  document.querySelectorAll('.copy-btn[data-copy]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const text = btn.dataset.copy;
      try {
        await navigator.clipboard.writeText(text);
        const orig = btn.textContent;
        btn.classList.add('copied');
        btn.textContent = '✓ Copied';
        showToast('Snippet copied');
        setTimeout(() => {
          btn.classList.remove('copied');
          btn.textContent = orig;
        }, 1800);
      } catch (e) {
        showToast('Copy failed : select manually');
      }
    });
  });

  // Final CTA: "Produce my first frame" toast
  const produceBtn = document.getElementById('produce-btn');
  if (produceBtn) {
    produceBtn.addEventListener('click', (e) => {
      e.preventDefault();
      showToast('Tell your AI: "Cut me a frame using the Reel lens."');
    });
  }

  // ── Modal: preview any lens's example inline ──
  const overlay = document.getElementById('modal-overlay');
  const iframe = document.getElementById('modal-iframe');
  const lensNameEl = document.getElementById('modal-lens-name');
  const copyBtn = document.getElementById('modal-copy');
  const closeBtn = document.getElementById('modal-close');
  let currentBlobUrl = null;
  let currentPrompt = '';

  function openExample(templateId, lensName, prompt) {
    const tpl = document.getElementById(templateId);
    if (!tpl) { showToast('Preview not available'); return; }
    if (currentBlobUrl) URL.revokeObjectURL(currentBlobUrl);
    // Payloads are base64-encoded at build time. Decode to get the raw HTML document.
    const raw = (tpl.textContent || tpl.innerHTML).trim();
    const html = new TextDecoder('utf-8').decode(Uint8Array.from(atob(raw), c => c.charCodeAt(0)));
    const blob = new Blob([html], { type: 'text/html' });
    currentBlobUrl = URL.createObjectURL(blob);
    iframe.src = currentBlobUrl;
    lensNameEl.textContent = lensName;
    currentPrompt = prompt || '';
    copyBtn.style.display = currentPrompt ? '' : 'none';
    copyBtn.classList.remove('copied');
    copyBtn.textContent = 'Copy prompt';
    overlay.dataset.open = 'true';
    document.body.style.overflow = 'hidden';
    closeBtn.focus();
  }
  function closeExample() {
    overlay.dataset.open = 'false';
    iframe.src = 'about:blank';
    document.body.style.overflow = '';
    if (currentBlobUrl) { URL.revokeObjectURL(currentBlobUrl); currentBlobUrl = null; }
  }

  document.querySelectorAll('.view-btn[data-example]').forEach(btn => {
    btn.addEventListener('click', () => {
      openExample(btn.dataset.example, btn.dataset.lens, btn.dataset.prompt || '');
    });
  });

  copyBtn.addEventListener('click', async () => {
    if (!currentPrompt) return;
    try {
      await navigator.clipboard.writeText(currentPrompt);
      copyBtn.classList.add('copied');
      copyBtn.textContent = '✓ Copied';
      showToast('Prompt copied : paste into your AI');
      setTimeout(() => {
        copyBtn.classList.remove('copied');
        copyBtn.textContent = 'Copy prompt';
      }, 1800);
    } catch (e) {
      showToast('Copy failed : select manually');
    }
  });

  closeBtn.addEventListener('click', closeExample);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeExample(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay.dataset.open === 'true') closeExample(); });
})();
