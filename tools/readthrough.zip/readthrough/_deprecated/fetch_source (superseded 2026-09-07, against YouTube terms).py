#!/usr/bin/env python3
"""A URL in, captions and optionally the video out, with the known traps guarded.

    python fetch_source.py URL --out inbox/my-recording
    python fetch_source.py URL --out DIR --captions-only

WHY THIS EXISTS RATHER THAN A COMMAND IN A README. Every one of the guards below
is a failure that already happened, recorded in
video-processing-pipeline/experiments/2026-09_prickly-pear-from-youtube.

  1. yt-dlp exits 0 on a failed download. A 403 printed ERROR on stderr and still
     returned 0. Anything that trusted the exit code carried on and looked for a
     file that was never written. So every step here asserts the file exists and
     has size, and the exit code is not trusted anywhere.

  2. Four different errors had one cause. A 403, a reload error and two cookie
     failures all pointed at different things. None was the problem: the
     downloader was six weeks old. YouTube breaks yt-dlp on a scale of weeks, so
     this prints the version and its age before it does anything, and says what
     to do first if a download fails. It does not reach for cookies.

  3. Automatic captions are enough to read a recording and not enough to cut it.
     Caption timings locate a passage. A cut point comes off a 20ms energy map.
     That line is printed on every run so nobody carries a caption timing into a
     cut.

WHAT IT DOES NOT DO. It does not decide whether you have any business cutting the
thing. The last run pulled a recording from somebody else's channel and the
question was left open on purpose. It is a person's call, and this prints the
uploader so the question is in front of you rather than behind you.
"""

import argparse
import json
import re
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

# 14 rather than 21: the recorded break was at six weeks, but the warning is only
# useful before a live run, so it fires early and says what to do.
STALE_DAYS = 14


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def version_note():
    r = run(["yt-dlp", "--version"])
    v = (r.stdout or "").strip()
    if not v:
        print("yt-dlp is not on PATH. Nothing here can run without it.", file=sys.stderr)
        return None, None
    age = None
    m = re.match(r"(\d{4})\.(\d{1,2})\.(\d{1,2})", v)
    if m:
        try:
            age = (date.today() - date(*(int(x) for x in m.groups()))).days
        except ValueError:
            age = None
    return v, age


def existing(p, what):
    """yt-dlp exits 0 on a failed download, so the file is the only proof."""
    if not p or not Path(p).is_file() or Path(p).stat().st_size == 0:
        print("  MISSING: " + what + " was not written.", file=sys.stderr)
        return False
    print("  ok %-9s %s  %s" % (what, format(Path(p).stat().st_size, ","), Path(p).name))
    return True


def probe(url):
    r = run(["yt-dlp", "--no-warnings", "--skip-download", "--dump-json", url])
    if r.returncode != 0 or not r.stdout.strip():
        return None, (r.stderr or "").strip()[:400]
    try:
        return json.loads(r.stdout.splitlines()[0]), None
    except Exception as e:
        return None, str(e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--out", required=True)
    ap.add_argument("--captions-only", action="store_true")
    ap.add_argument("--height", type=int, default=720,
                    help="cap the video height. 360 reads fine and is small; "
                         "720 is the default because 360 was too low to deliver from.")
    ap.add_argument("--name", default=None, help="basename for the files")
    a = ap.parse_args()

    v, age = version_note()
    if not v:
        return 1
    print("yt-dlp " + v + (" (%d days old)" % age if age is not None else ""))
    if age is not None and age >= STALE_DAYS:
        print("  NOTE: past %d days. Every download failure recorded here so far was"
              " this, not cookies and not the client." % STALE_DAYS)
        print("  If it fails: python -m pip install -U --pre \"yt-dlp[default]\" and run again.")

    out = Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    print("\nreading the page")
    info, err = probe(a.url)
    if not info:
        print("  could not read it: " + (err or "no output"), file=sys.stderr)
        print("  first move is the version above, not cookies.", file=sys.stderr)
        return 1
    dur = info.get("duration") or 0
    base = a.name or re.sub(r"[^\w\-]+", "-", (info.get("id") or "source")).strip("-")
    print("  title     " + str(info.get("title"))[:80])
    print("  uploader  " + str(info.get("uploader")))
    print("  runs      %d:%02d:%02d" % (dur // 3600, dur % 3600 // 60, dur % 60))
    subs = sorted((info.get("automatic_captions") or {}).keys())
    print("  auto captions: " + (", ".join(subs[:6]) + (" ..." if len(subs) > 6 else "") if subs else "none"))
    if not subs and not (info.get("subtitles") or {}):
        print("  no captions at all. The read-through needs some, so this would have to be"
              " transcribed locally first.", file=sys.stderr)

    tmpl = str(out / (base + ".%(ext)s"))
    print("\nfetching captions")
    run(["yt-dlp", "--no-warnings", "--skip-download", "--write-auto-subs",
         "--write-subs", "--sub-langs", "en.*", "--sub-format", "vtt",
         "-o", tmpl, a.url])
    vtt = next(iter(sorted(out.glob(base + "*.vtt"))), None)
    ok = existing(vtt, "captions")

    video = None
    if not a.captions_only:
        print("\nfetching video, height capped at %d" % a.height)
        run(["yt-dlp", "--no-warnings",
             "-f", "bv*[height<=%d]+ba/b[height<=%d]/b" % (a.height, a.height),
             "--merge-output-format", "mp4", "-o", tmpl, a.url])
        video = next((p for p in sorted(out.glob(base + ".*"))
                      if p.suffix.lower() in (".mp4", ".mkv", ".webm")), None)
        ok = existing(video, "video") and ok

    (out / "source.json").write_text(json.dumps({
        "schema": "readthrough-source/v1",
        "url": a.url,
        "fetched": datetime.now().isoformat(timespec="seconds"),
        "yt_dlp_version": v,
        "title": info.get("title"),
        "uploader": info.get("uploader"),
        "duration_s": dur,
        "captions": vtt.name if vtt else None,
        "captions_are": "automatic. Good enough to locate a passage, not to place a cut.",
        "video": video.name if video else None,
        "height_cap": None if a.captions_only else a.height,
        "rights": "Not checked here. Whether this is yours to cut is a person's call.",
    }, indent=1), encoding="utf-8")

    print("\n" + ("ready" if ok else "INCOMPLETE"))
    print("  wrote source.json beside the files")
    print("  captions locate a passage. A cut point still comes off the waveform at 20ms.")
    if not ok:
        return 1
    print("\nnext:")
    print("  python run.py --captions %s%s --out-dir %s --title \"%s\""
          % (vtt.name, "" if a.captions_only else " --video " + video.name, out.name,
             str(info.get("title") or base).replace('"', "'")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
