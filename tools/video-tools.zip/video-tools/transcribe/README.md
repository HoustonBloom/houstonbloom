# transcribe

**A whole recording in, a caption file out.** One script, one step, for a file
that arrived with none. Everything else in this folder reads captions.

```bash
pip install -r requirements.txt          # plus ffmpeg on PATH
python scripts/transcribe.py --video IN.mp4 --out captions.vtt
```

Then the readthrough:

```bash
python ../readthrough/scripts/run.py --captions captions.vtt --video IN.mp4 --out-dir . --title "..."
```

## Why it exists

Until 2026-09-07 a recording came with captions because it was fetched from
YouTube, and the fetch is gone: it was against YouTube's terms. A recording
arrives now as a file from whoever owns it, and a file has no captions.
`shorts/scripts/make_captions.py` transcribes, but one cut plan's segments at a
time, for burning in. Nothing made captions for a whole file.

## What it reuses

The three traps `make_captions.py` paid for, unchanged:

- **faster-whisper returns nothing at source level**, about -34 dBFS. The audio
  is lifted to -16 LUFS first, mono, 16 kHz, with a 75 Hz high-pass. That is
  not a delivery level; it is the level at which the model stops returning
  nothing.
- **It loops on repetition.** Temperature fallback and a repetition penalty are
  on, and each window is transcribed without the previous text as context.
- **It emits phantom words in silence.** The VAD filter is on.

`--model small` is the one measured on this footage. Medium is untested here,
TODO 4 in the folder above.

## What it does not do

- **It does not name speakers.** Zoom and Teams transcripts do; this does not.
- **It does not invent a word.** Where the model is unsure the word is still
  the model's, and proper nouns are the least reliable part. Every transcript
  in this folder has misheard a name. Read them against the tape.
- **It cannot place a cut.** A cue time locates a passage.

## Measured

| Recording | Runs | Model | Wall time | Cues | Words |
|---|---|---|---|---|---|
| Gardens, Not Platforms, 2026 | 1:10:38 | small, CPU int8, 10 minute windows | 23m49s, of which 4m15s normalising | 1,398 | 9,822 |

So about a third of the recording's length on this machine, no GPU. The first
attempt handed the model the whole hour and its feature pass asked for 616 MiB
in one array and did not get it; the windows are why.
