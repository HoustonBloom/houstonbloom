#!/usr/bin/env python
"""
A page to pick from. Point it at a folder of stills and it renders one HTML page
holding every picture under it, grouped, filterable, click through to full size.

It reads the manifests `pick_stills.py` and `crop_stills.py` left beside the
pictures, so the page states where each frame came from and at what timecode
without anybody retyping it. **The source table is derived, never written by
hand.** An earlier version kept the bitrates in a metadata file beside the
builder and they had to be hand-corrected in two places when a measurement
changed.

Structure is whatever is on disk. Any folder under the root holding a manifest
becomes a group, and the folder above it becomes the filter it sits under. So
this works on a flat folder and on a `full frames/` plus `feed crops/` split
without being told which it is.

Output is `contact-sheet.html` plus a `_thumbs/` folder, both in the root. Both
are build output. Change this file, then run it again.

Usage:
    python build_sheet.py --root DIR
    python build_sheet.py --root DIR --title "Founder's Couch stills"
"""
import argparse
import html
import json
import re
import shutil
from datetime import date
from pathlib import Path

import cv2

THUMB_W = 420


def pretty_tc(tc):
    """Manifests store 37-32.000, because a colon cannot go in a filename."""
    m = re.match(r"^(\d+)-(\d+)\.\d+$", tc or "")
    return "%s:%s" % (m.group(1), m.group(2)) if m else (tc or "")


def hms(seconds):
    if not seconds:
        return ""
    s = int(round(seconds))
    return "%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)


def load_manifests(folder):
    rows, sources = {}, []
    for mf in sorted(folder.glob("*.stills.json")) + sorted(folder.glob("*.crops.json")):
        try:
            d = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            continue
        src = d.get("source")
        if isinstance(src, dict):
            sources.append(src)
        for r in d.get("picks", []) + d.get("crops", []):
            rows[r["file"]] = r
    return rows, sources


def thumb_for(img, key, thumbs):
    out = thumbs / key.replace("/", "__")
    im = cv2.imread(str(img))
    if im is None:
        return False
    h, w = im.shape[:2]
    im = cv2.resize(im, (THUMB_W, max(1, round(h * THUMB_W / w))), interpolation=cv2.INTER_AREA)
    cv2.imwrite(str(out), im, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return True


def collect(root, thumbs):
    groups, sources = [], {}
    for folder in sorted(p for p in root.rglob("*") if p.is_dir()):
        if thumbs == folder or thumbs in folder.parents or folder.name.startswith("_"):
            continue
        man, srcs = load_manifests(folder)
        if not man:
            continue
        for s in srcs:
            sources.setdefault(s.get("path") or s.get("name", "?"), s)

        rel_folder = folder.relative_to(root)
        section = rel_folder.parts[0] if len(rel_folder.parts) > 1 else "Stills"
        items = []
        for img in sorted(folder.glob("*.jpg")):
            key = "%s/%s" % (rel_folder.as_posix(), img.name)
            if not thumb_for(img, key, thumbs):
                continue
            m = man.get(img.name, {})
            px = m.get("crop_px") or ([m["width"], m["height"]] if m.get("width") else None)
            items.append({
                "href": key,
                "thumb": "_thumbs/" + key.replace("/", "__"),
                "name": img.name,
                "tc": pretty_tc(m.get("at_timecode", "")),
                "px": ("%d x %d" % tuple(px)) if px else "",
                "kb": round(img.stat().st_size / 1024),
                "note": m.get("centred_on", "") if m.get("subject") else "",
            })
        if items:
            groups.append({"section": section.replace("_", " "),
                           "folder": rel_folder.parts[-1], "items": items})
    return groups, list(sources.values())


CSS = """
:root{--ink:#16151a;--muted:#6c6a75;--line:#e3e1e8;--bg:#faf9fb;--card:#fff;--accent:#7a3ea3}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
     font:15px/1.55 ui-sans-serif,system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
header{padding:34px 30px 22px;border-bottom:1px solid var(--line);background:var(--card)}
h1{margin:0 0 6px;font-size:26px;letter-spacing:-.015em}
.sub{color:var(--muted);max-width:74ch;margin:0 0 16px}
table.q{border-collapse:collapse;font-size:13px}
table.q th,table.q td{border:1px solid var(--line);padding:5px 11px;text-align:left}
table.q th{background:#f3f1f6;font-weight:600}
nav{position:sticky;top:0;z-index:5;background:var(--card);border-bottom:1px solid var(--line);
    padding:11px 30px;display:flex;flex-wrap:wrap;gap:7px}
nav button{font:inherit;font-size:13px;padding:5px 12px;border:1px solid var(--line);
           border-radius:999px;background:#fff;color:var(--ink);cursor:pointer}
nav button[aria-pressed=true]{background:var(--accent);border-color:var(--accent);color:#fff}
main{padding:26px 30px 60px}
section h2{font-size:14px;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);
           margin:32px 0 3px;font-weight:600}
section .count{color:var(--muted);font-size:13px;margin:0 0 14px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
figure{margin:0;background:var(--card);border:1px solid var(--line);border-radius:9px;overflow:hidden}
figure a{display:block;line-height:0}
figure img{width:100%;height:auto}
figcaption{padding:9px 11px;font-size:12px;color:var(--muted);line-height:1.45}
figcaption b{display:block;color:var(--ink);font-weight:600;font-size:12.5px;
             word-break:break-word;margin-bottom:2px}
footer{padding:22px 30px 50px;color:var(--muted);font-size:13px;border-top:1px solid var(--line)}
"""

JS = """
const btns=[...document.querySelectorAll('nav button')];
btns.forEach(b=>b.addEventListener('click',()=>{
  btns.forEach(o=>o.setAttribute('aria-pressed',String(o===b)));
  const f=b.dataset.filter;
  document.querySelectorAll('section').forEach(s=>{
    s.hidden = !(f==='all' || s.dataset.section===f);
  });
}));
"""


def render(groups, sources, title, blurb):
    sections = sorted({g["section"] for g in groups})
    nav = ['<button data-filter="all" aria-pressed="true">Everything</button>']
    nav += ['<button data-filter="%s" aria-pressed="false">%s</button>'
            % (html.escape(s), html.escape(s)) for s in sections]

    body = []
    for g in groups:
        cards = []
        for it in g["items"]:
            bits = [b for b in (it["tc"] and "at " + it["tc"], it["px"], "%d KB" % it["kb"]) if b]
            note = ("<br>" + html.escape(it["note"])) if it["note"] else ""
            cards.append(
                '<figure><a href="%s" target="_blank" rel="noopener">'
                '<img src="%s" loading="lazy" alt=""></a>'
                "<figcaption><b>%s</b>%s%s</figcaption></figure>"
                % (html.escape(it["href"]), html.escape(it["thumb"]),
                   html.escape(it["name"]),
                   " &middot; ".join(html.escape(b) for b in bits), note))
        body.append(
            '<section data-section="%s"><h2>%s &middot; %s</h2>'
            '<p class="count">%d pictures</p><div class="grid">%s</div></section>'
            % (html.escape(g["section"]), html.escape(g["section"]),
               html.escape(g["folder"]), len(g["items"]), "".join(cards)))

    qrows = []
    for s in sorted(sources, key=lambda s: -(s.get("video_bitrate_bps") or 0)):
        br = s.get("video_bitrate_bps")
        qrows.append("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (
            html.escape(Path(s.get("path", "?")).name),
            html.escape("%s x %s%s%s" % (
                s.get("width", "?"), s.get("height", "?"),
                ", %s fps" % s["fps"] if s.get("fps") else "",
                ", " + hms(s.get("duration_s")) if s.get("duration_s") else "")),
            html.escape("%.1f Mbit/s" % (br / 1e6) if br else "not reported")))

    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>%s</title><style>%s</style></head>
<body>
<header>
<h1>%s</h1>
<p class="sub">%s</p>
<table class="q"><tr><th>Cut from</th><th>Picture</th><th>Video bitrate</th></tr>%s</table>
</header>
<nav>%s</nav>
<main>%s</main>
<footer>Built %s. Click any picture to open it full size.</footer>
<script>%s</script>
</body></html>
""" % (html.escape(title), CSS, html.escape(title), html.escape(blurb),
       "".join(qrows), "".join(nav), "".join(body), date.today().isoformat(), JS)


def main():
    ap = argparse.ArgumentParser(description="Render a page to pick stills from.")
    ap.add_argument("--root", required=True)
    ap.add_argument("--title", default="Stills")
    ap.add_argument("--blurb", default="Every frame here came straight out of the source "
                                       "at full resolution, and nothing was scaled up. "
                                       "Click a picture to open it, then save the one you want.")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    thumbs = root / "_thumbs"
    if thumbs.exists():
        shutil.rmtree(thumbs)
    thumbs.mkdir(parents=True, exist_ok=True)

    groups, sources = collect(root, thumbs)
    (root / "contact-sheet.html").write_text(
        render(groups, sources, args.title, args.blurb), encoding="utf-8")
    n = sum(len(g["items"]) for g in groups)
    print("  contact-sheet.html: %d pictures across %d folders, %d source%s"
          % (n, len(groups), len(sources), "" if len(sources) == 1 else "s"))


if __name__ == "__main__":
    main()
